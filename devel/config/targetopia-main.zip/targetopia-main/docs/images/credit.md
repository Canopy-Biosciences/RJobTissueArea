* `ideas.png`: https://publicdomainvectors.org/en/free-clipart/Bulb-vector-image/8286.html
* `targetopia/`: https://publicdomainvectors.org/en/free-clipart/Plant-silhouette/40390.html with permission.
