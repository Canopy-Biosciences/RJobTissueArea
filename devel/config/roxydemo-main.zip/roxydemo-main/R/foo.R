
#' Foo
#'
#' @param bar bar
#'
#' @return bar
#' @tip Here is the custom roxygen section
#' @export
#'
foo <- function(bar){
    bar
}

