tab_progress <- bs4TabItem(
  "progress",
  tar_watch_ui("targets-shiny", seconds = 15, targets_only = TRUE)
)
