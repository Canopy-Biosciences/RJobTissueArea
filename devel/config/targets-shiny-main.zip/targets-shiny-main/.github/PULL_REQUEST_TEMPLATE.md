# Prework

* [ ] I understand and agree to the [code of conduct](https://contributor-covenant.org/version/2/0/CODE_OF_CONDUCT.html) and the [contributing guidelines](https://github.com/wlandau/targets-shiny/blob/main/CONTRIBUTING.md).
* [ ] I have already submitted a [discussion topic](https://github.com/wlandau/targets-shiny/discussions) or [issue](http://github.com/wlandau/targets-shiny/issues) to discuss my idea with the maintainer.
* [ ] This pull request is not a [draft](https://github.blog/2019-02-14-introducing-draft-pull-requests).

# Related GitHub issues and pull requests

* Ref: #

# Summary

Please explain the purpose and scope of your contribution.
