
test_that("another good one", {
  for (i in 1:100) expect_true(TRUE)
})

test_that("and another", {
  for (i in 1:10) expect_true(TRUE)
})
