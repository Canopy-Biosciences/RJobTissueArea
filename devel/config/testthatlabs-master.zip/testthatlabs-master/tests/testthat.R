library(testthat)
library(testthatlabs)

test_check("testthatlabs")
