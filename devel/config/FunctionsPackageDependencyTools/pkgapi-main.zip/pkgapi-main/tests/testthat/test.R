
context("pkgapi")

test_that("pkgapi works", {

  expect_true(TRUE)

})
