library(testthat)
library(pkgapi)

test_check("pkgapi")
