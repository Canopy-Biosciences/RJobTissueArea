
#' Map Function Calls
#'
#' Create the map function calls in a package, including calls to imported
#' packages.
#'
#' @docType package
#' @name pkgapi
NULL
