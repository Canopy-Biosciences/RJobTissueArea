my_plot = function(number_observations){
  hist(rnorm(number_observations), col = 'darkgray', border = 'white')
}