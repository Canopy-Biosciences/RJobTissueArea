library(testthat)
library(appPackage)

test_check("appPackage")
