# Prework

* [ ] I understand and agree to this repository's [code of conduct](https://github.com/wlandau/targetsketch/blob/main/CODE_OF_CONDUCT.md).
* [ ] I understand and agree to this repository's [contributing guidelines](https://github.com/wlandau/targetsketch/blob/main/CONTRIBUTING.md).
* [ ] I have already submitted an issue to the [issue tracker](http://github.com/wlandau/targetsketch/issues) to discuss my idea with the maintainer.

# Summary

Please explain the purpose and scope of your contribution.

# Related GitHub issues and pull requests

* Ref: #

# Checklist

* [ ] This pull request is not a [draft](https://github.blog/2019-02-14-introducing-draft-pull-requests).
