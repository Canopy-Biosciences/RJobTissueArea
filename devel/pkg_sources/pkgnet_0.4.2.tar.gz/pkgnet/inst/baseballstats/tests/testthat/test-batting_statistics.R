

test_that('at_bats runs end-to-end', expect_true({
    AB <- at_bats(c('bb', 'k', '1b', 'hr'))
    TRUE
}))