library(testthat)
library(silverstein)

test_check("silverstein")
