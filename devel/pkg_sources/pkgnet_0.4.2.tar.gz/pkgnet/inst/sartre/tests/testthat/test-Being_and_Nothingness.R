
test_that(desc = 'nothing works', {
  expect_type(object = somethingAboutNothing()
              , type = "character")
})
