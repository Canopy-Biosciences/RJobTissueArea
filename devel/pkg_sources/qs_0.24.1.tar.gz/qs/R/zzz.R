.onAttach <- function(libname, pkgname) {
  packageStartupMessage("qs v0.24.1.")
}
